//this function will be called when either success or failure happened
function show(msg)
{
    console.log(msg);
}
let mypromise=new Promise(function (myResolve,myReject) //myResolve will be called when success is done
{                                                       //myReject will be called when there is failure or error
let x=testusername("yukta@gmail.com","1232#@");
if (x==1)
myResolve("Your welcome"); //this is value
else if(x==0)
myReject("username did not matched with the password"); //this is error
else if(x==2)
myReject("no account found"); //this is error
});

mypromise.then(function(value){show(value);}, function(error){show(error);});

function testusername(un,pass)
{
    if(un=="yukta@gmail.com" && pass=="1232#@")
    return 1;
    else if(un!="yukta@gmail.com" && pass!="1232#@")
    return 2;
    else if(un!="yukta@gmail.com" || pass!="1232#@")
    return 0;
}