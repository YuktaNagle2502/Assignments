
for(a=1; a<=10; a++){
    if(a % 2 == 0){
    console. log(a);

for(let b = 1; b <= 10; b++) {

    const result = b * a;

    console.log(`${a} * ${b} = ${result}`);

    }

}

}