const count = (string) => { 
     
    let v = 0; 
    let c = 0; 
     
    for(let i = 0; i < string.length; i++){ 
        let x = string[i]; 
        if(x == 'a' || x == 'e' || x == 'i' || x == 'o' || x == 'u') 
            v += 1; 
        else 
            c += 1; 
    };
    console.log(string);
    console.log("vowels are: "+v); 
    console.log("consonants are: "+c); 
}; 
count("yukta"); 
