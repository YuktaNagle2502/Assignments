function * gen()
{
    yield 5;
    yield 10;
    yield 15;
}

var x=gen();
console.log("first value which is generated:-"+x.next().value); //5
console.log("second value which is generated:-"+x.next().value); //10
console.log("third value which is generated:-"+x.next().value); //15

var y=gen();
var p=y.next().value; //next value of y is 5
console.log("first value which is generated:-"+p); //p=5
for(let i=1;i<=p;i+=2)
console.log(i); //1 3 5
console.log("second value which is generated:-"+y.next().value); //next value of y is 10
console.log("third value which is generated:-"+y.next().value);  //next value of y is 15