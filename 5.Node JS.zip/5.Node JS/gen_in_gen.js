function * gen1()
{
    yield 2;
    yield 4;
}
function * gen2()
{
    yield 'a'; //a
    yield * gen1(); //2 4
    yield 'b'; //b
}
for(let v of gen2())
{
    console.log(v);
}
