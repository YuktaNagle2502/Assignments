function show() //normal function
{
    console.log("show function called");
}
show();

var x= function(a,b) //anonymous function
{
    console.log(a+b);
}
x(23,67);

var x=(a,b)=>(a+b) //arrow function 1st type
{
    console.log("sum is "+x(10,20));
}

var msg=()=>{ console.log("hello everyone");}
msg();

var si=(p,r,t)=>  //arrow function 2nd type
{
    return(p*r*t)/100;
}
console.log(si(1000,5,5));

//single parameter in arrow function
var u= m=>"value you passed " +m; //no need of brackets around the parameter 
console.log(u(1234));
console.log(u("sunil kumar"));
console.log(u(12.008));

const myfun=(x)=>x*x
console.log(myfun(10));