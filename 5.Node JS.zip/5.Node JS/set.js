const names=new Set(["anil","sunil","vijay"]);
console.log(names.size);

names.add("vikram");
names.add("vikas");
names.add("vinit");
console.log(names.size);

for(let x of names.values())
console.log(x);

names.delete("anil");
console.log("after deletion");
for(let x of names.values())
console.log(x);

names.forEach(function(v){
console.log(v);
});

names.add("vinit") //vinit will add only one time not two times as set is a collection of unique values
console.log("adding vinit again");
names.forEach(function(v){
console.log(v);
});