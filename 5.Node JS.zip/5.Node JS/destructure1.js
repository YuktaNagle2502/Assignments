var carlist = ['maruti suzuki','tata' ,' renault' ,'bmw'];
var [car1,car2,car3,car4]= carlist;
console.log(car2); //tata
console.log(car4); //bmw
var [car11,,,car14]= carlist;
console.log(car11); //maruti suzuki
console.log(car14); //bmw