class sstatic
{
    static show()
    {
        console.log("this is static show");
    }
}
sstatic.show();