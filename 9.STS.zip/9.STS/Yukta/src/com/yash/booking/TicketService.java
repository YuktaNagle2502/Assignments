package com.yash.booking;

import java.util.List;
import java.sql.*;
import java.time.LocalDate;
import java.util.LinkedList;

public class TicketService {

	private static List<Ticket> ticket = new LinkedList<>();

	public static void addNewTicket(int busNumber, List<BookTicket> passengerList) {
		int pnr = ticket.size() + 1;
		BusService x = new BusService();
		BusBooking bookedBus = x.findBus(busNumber);
		ticket.add(new Ticket(pnr, bookedBus, passengerList));
		System.out.println("Ticket is booked Successfully");
	}

	public static void showTicketDetails(int pnr) {
		Ticket temp = null;
		for (Ticket t : ticket) {
			if (t.getPnr() == pnr) {
				temp = t;
				break;
			}
		}
		BusBooking tempBus = temp.getBookedBus();
		List<BookTicket> passengerList = temp.getPassengerList();

		System.out.println("BOOKING DETAILS ARE:");
		System.out.println("PNR= " + temp.getPnr());
		System.out.println("Bus Number: " + tempBus.getbusNumber());
		System.out.println("Bus name: " + tempBus.getbusName());
		System.out.println("Starting station: " + tempBus.getstationStarting());
		System.out.println("Ending station: " + tempBus.getstationEnding());
		System.out.println("Date of Journey: " + tempBus.getjourneyDate());
		System.out.println("Ticket Price: " + tempBus.getPrice());

		System.out.println("\nPassenger information:\n");
		System.out.println("BusNumber Name   Age");
		for (BookTicket p : passengerList) {
			System.out.println(p.getbusNumber() + "\t" + p.getPassengerName() + "\t" + p.getPassengerAge());
		}

		try {
			// load the driver
			Class.forName("com.mysql.jdbc.Driver");
			// creating connection
			String url = "jdbc:mysql://localhost:3306/yash";
			String user = "root";
			String pass = "root";

			Connection con = DriverManager.getConnection(url, user, pass);

			pnr = temp.getPnr();
			int Bus_Number = tempBus.getbusNumber();
			String Bus_Name = tempBus.getbusName();
			String Starting_Station = tempBus.getstationStarting();
			String Ending_Station = tempBus.getstationEnding();
			LocalDate Journey_Date = tempBus.getjourneyDate();
			int Ticket_Price = tempBus.getPrice();

			String k = "insert into Ticket_Details(pnr,Bus_Number,Bus_Name,Starting_Station,Ending_Station,Journey_Date,Ticket_Price) values(?,?,?,?,?,?,?)";
			PreparedStatement pt = con.prepareStatement(k);
			pt.setInt(1, pnr);
			pt.setInt(2, Bus_Number);
			pt.setString(3, Bus_Name);
			pt.setString(4, Starting_Station);
			pt.setString(5, Ending_Station);
			pt.setObject(6, Journey_Date);
			pt.setInt(7, Ticket_Price);
			pt.executeUpdate();
			System.out.println("Ticket details is inserted successfully");
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
