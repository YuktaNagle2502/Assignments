package com.yash.booking;

import java.sql.Connection;
import java.sql.DriverManager;
import java.time.LocalDate;

public class BusBooking {
	private int busNumber;
	private String busName;
	private String stationStarting;
	private String stationEnding;
	private int price;
	private LocalDate journeyDate;

	public BusBooking(int busNumber, String busName, String stationStarting, String stationEnding, int price,
			LocalDate journeyDate) {
		this.busNumber = busNumber;
		this.busName = busName;
		this.stationStarting = stationStarting;
		this.stationEnding = stationEnding;
		this.price = price;
		this.journeyDate = journeyDate;
	}

	public int getbusNumber() {
		return busNumber;
	}

	public void setbusNumber(int busNumber) {
		this.busNumber = busNumber;
	}

	public String getbusName() {
		return busName;
	}

	public void setbusName(String busName) {
		this.busName = busName;
	}

	public String getstationStarting() {
		return stationStarting;
	}

	public void setStationStarting(String stationStarting) {
		this.stationStarting = stationStarting;
	}

	public String getstationEnding() {
		return stationEnding;
	}

	public void setStationEnding(String stationEnding) {
		this.stationEnding = stationEnding;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public LocalDate getjourneyDate() {
		return journeyDate;
	}

	public void setjourneyDate(LocalDate journeyDate) {
		this.journeyDate = journeyDate;
	}

}
