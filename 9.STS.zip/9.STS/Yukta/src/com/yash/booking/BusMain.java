package com.yash.booking;

import java.time.LocalDate;
import java.sql.*;
import java.util.Scanner;
import java.util.List;
import java.util.LinkedList;

public class BusMain {
	public static void main(String args[]) {

		try {
			// load the driver
			Class.forName("com.mysql.jdbc.Driver");
			// creating connection
			String url = "jdbc:mysql://localhost:3306/yash";
			String user = "root";
			String pass = "root";

			Connection con = DriverManager.getConnection(url, user, pass);
			if (con != null) {
				System.out.println("Connection is created successfully");
			} else
				System.out.println("Connection is not created");

			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the starting "
					+ "station:");
			String stationStarting = sc.nextLine();
			System.out.println("Enter the ending station:");
			String stationEnding = sc.nextLine();

			System.out.println("Searching for the buses...");

			BusService x = new BusService();
			x.stations(stationStarting, stationEnding);

			System.out.println("Enter the bus number:");
			int busNumber = sc.nextInt();

			System.out.println("Enter the pnr:");
			int pnr = sc.nextInt();

			System.out.println("Enter passenger's name:");
			String passengerName = sc.next();
			System.out.println("Enter passenger's age:");
			int passengerAge = sc.nextInt();

			BookTicket p1 = new BookTicket(busNumber, passengerName, passengerAge);

			List<BookTicket> passengerList = new LinkedList<>();
			passengerList.add(p1);

			System.out.println("Ticket details:");

			TicketService.addNewTicket(busNumber, passengerList);

			TicketService.showTicketDetails(pnr);

			// create query

			String name = p1.getPassengerName();
			int age = p1.getPassengerAge();

			String s = "insert into Passenger_info(busNumber,Name,Age) values(?,?,?)";
			PreparedStatement st = con.prepareStatement(s);
			st.setInt(1, busNumber);
			st.setString(2, name);
			st.setInt(3, age);
			st.executeUpdate();
			System.out.println("Passenger's information is inserted successfully");
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
