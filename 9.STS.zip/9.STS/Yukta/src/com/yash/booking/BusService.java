package com.yash.booking;

import java.util.List;
import java.util.LinkedList;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;

public class BusService {
	private static List<BusBooking> buses = new LinkedList<>();
	static {
		buses.add(new BusBooking(1, "Chartered bus", "Indore", "Bhopal", 500, LocalDate.now()));
		buses.add(new BusBooking(2, "Annapurna bus", "Indore", "Bhopal", 400, LocalDate.now()));
		buses.add(new BusBooking(3, "Chartered bus", "Bhopal", "Indore", 500, LocalDate.now()));
		buses.add(new BusBooking(4, "Soumya Travels", "Bhopal", "Indore", 400, LocalDate.now()));
		buses.add(new BusBooking(5, "Narayana Travels", "Indore", "Ujjain", 250, LocalDate.now()));
		buses.add(new BusBooking(6, "Chartered bus", "Ujjain", "Indore", 250, LocalDate.now()));
	}

	public void stations(String stationStarting, String stationEnding) {
		List<BusBooking> busList = new LinkedList<>();
		for (BusBooking b : buses) {
			if (b.getstationStarting().equals(stationStarting) && b.getstationEnding().equals(stationEnding)) {
				busList.add(b);
			}
		}

		if (busList.size() == 0) {
			System.out.println("No matching bus");
		} else {
			for (BusBooking b : busList) {
				System.out.println("Bus number: " + b.getbusNumber() + "  Bus name: " + b.getbusName()
						+ "  Station starting: " + b.getstationStarting() + "  Station ending: " + b.getstationEnding()
						+ "  Price: " + b.getPrice() + "  Journey date: " + b.getjourneyDate());
			}
		}
	}

	public BusBooking findBus(int busNumber) {
		BusBooking book = null;
		for (BusBooking b : buses) {
			if (b.getbusNumber() == busNumber) {
				book = b;
				break;
			}
		}
		return book;
	}
}
