package com.yash.booking;

public class BookTicket {
	private String passengerName;
	private int passengerAge;
	private int busNumber;

	public BookTicket(int busNumber, String passengerName, int passengerAge) {
		this.busNumber = busNumber;
		this.passengerName = passengerName;
		this.passengerAge = passengerAge;
	}

	public int getbusNumber() {
		return busNumber;
	}

	public void setbusNumber(int busNumber) {
		this.busNumber = busNumber;
	}

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public int getPassengerAge() {
		return passengerAge;
	}

	public void setPassengerAge(int passengerAge) {
		this.passengerAge = passengerAge;
	}

}