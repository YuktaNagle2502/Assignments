package com.automobile.twowheeler;
import com.automobile.Vehicle;
public class Honda extends Vehicle
{
	public int getSpeed()
	{
		return 100;
	}
	public void cdPlayer()
	{
		System.out.println("CD player");
	}
	public String getModelName()
	{
		return "Honda";
	}
	public String getRegistrationNumber()
	{
		return "9876";
	}
	public String getOwnerName()
	{
		return "Yukta";
	}
}