package com.automobile;
import com.automobile.twowheeler.*;
public class Test
{
	public static void main(String args[])
	{
		Honda h=new Honda();
		System.out.println(h.getSpeed());
		
		Hero o=new Hero();
		System.out.println(o.getSpeed());
	}
}