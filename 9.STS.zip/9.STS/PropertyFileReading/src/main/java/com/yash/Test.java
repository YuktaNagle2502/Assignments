package com.yash;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.ApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context=new ClassPathXmlApplicationContext("Beans.xml");
		System.out.println(context.getMessage("message", null,"Default Message",null));
		((AbstractApplicationContext) context).close();
	}

}
