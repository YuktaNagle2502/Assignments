package eventhandlingdemo;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ConfigurableApplicationContext context= new ClassPathXmlApplicationContext("applicationcontext.xml");
		context.start();
		Message m=(Message)context.getBean("message");
		m.getMessage();
		context.stop();
	}

}
