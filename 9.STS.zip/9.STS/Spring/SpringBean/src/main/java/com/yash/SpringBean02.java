package com.yash;

import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.BeansException;

public class SpringBean02 implements BeanPostProcessor {
	
  
   public Object postProcessBeforeInitialization(Object bean, String string) 
      throws BeansException {
      
      System.out.println("Before Initialization" );
      return bean;  
   }
   public Object postProcessAfterInitialization(Object bean, String string) 
      throws BeansException {
      
      System.out.println("After Initialization");
      return bean; 
   }
}