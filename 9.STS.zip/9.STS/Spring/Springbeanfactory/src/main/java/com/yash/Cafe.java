package com.yash;

public class Cafe {

	String welcome;

	public String getWelcome() {
		return welcome;
	}

	public void setWelcome(String welcome) {
		this.welcome = welcome;
	}
	
	public void customer() {
		// TODO Auto-generated method stub
		System.out.println(welcome);
	}
}
