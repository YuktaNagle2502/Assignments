package springcollection;
import java.util.*;

public class Collection {

	List li;
	Set s;
	Map m;
	public List getLi() {
		return li;
	}
	public void setLi(List li) {
		this.li = li;
	}
	public Set getS() {
		return s;
	}
	public void setS(Set s) {
		this.s = s;
	}
	public Map getM() {
		return m;
	}
	public void setM(Map m) {
		this.m = m;
	}
	@Override
	public String toString() {
		return "Collection [li=" + li + ", s=" + s + ", m=" + m + "]";
	}
	
	
}
