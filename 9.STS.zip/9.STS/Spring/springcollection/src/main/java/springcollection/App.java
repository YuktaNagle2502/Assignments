package springcollection;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.ApplicationContext;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        ApplicationContext context=new ClassPathXmlApplicationContext("applicationcontext.xml");
        Collection c=(Collection)context.getBean("CollectionDemo");
        System.out.print(c);
	}

}
