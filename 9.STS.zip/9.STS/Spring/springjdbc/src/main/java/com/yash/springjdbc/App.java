package com.yash.springjdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import com.yash.springjdbc.dao.StudentDao;
import com.yash.springjdbc.entities.Student;

public class App
{
public static void main( String[] args )
{
System.out.println( "Hello World!" );
ApplicationContext context=new ClassPathXmlApplicationContext("com/yash/springjdbc/applicationcontext.xml");
StudentDao stdao=context.getBean("StudentDao",StudentDao.class);
Student s=new Student();
s.setId(108);
s.setName("yuktaa");
//int r=stdao.insert(s);
//int r=stdao.updatedetails(s);
//System.out.println(r + "Student details updated Successfully ");
//System.out.println(r + "Student added Successfully ");
int r=stdao.deletedetails(108);
System.out.println(r + "Student deleted Successfully ");

}
}


