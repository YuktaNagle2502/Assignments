import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class CollectionDemo {

	public static void main(String[] args) {
		ArrayList a=new ArrayList();
		a.add(10);
		a.add("yash");
		a.add('j');
		a.add('j');
		System.out.println(a);
		//HashSet h=new HashSet();
		//h.add("tech");
		//h.add(20);
		//HashMap hm=new HashMap();
		//hm.put(1000,"yash");

	}

}
