
public class DebuggerDemo {

public static void main(String[] args)
    {
		int i=100;
		if(i==0)
		{
		 System.out.println("Neither positive integer nor negative");
		}
		else 
	    if(i>0)
		{
			System.out.println("Positive integer");
		}
		else
		{
			System.out.println("negative integer");
		}
	}

}
