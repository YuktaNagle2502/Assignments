package com.yash.jerseyDemo2;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;

@XmlRootElement
public class Resource5 {
private String name;
private int marks;

public Resource5()
{
}
@XmlElement
public String getName() {
	return name;
}
@XmlElement
public void setName(String name) {
	this.name = name;
}
@XmlElement
public int getMarks() {
	return marks;
}
@XmlElement
public void setMarks(int marks) {
	this.marks = marks;
}


}
