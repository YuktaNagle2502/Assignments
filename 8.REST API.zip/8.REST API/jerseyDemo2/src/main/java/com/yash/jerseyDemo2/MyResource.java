package com.yash.jerseyDemo2;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

class jkl
{
	private int n;
	public void setN(int n)
	{
		this.n=n;
	}
	public int getN()
	{
		return this.n;
	}
}
@Path("myresource")
public class MyResource {
    @GET
    @Produces(MediaType.APPLICATION_XML)
    public String getIt() {
    	System.out.println("Check");
    	jkl JKL=new jkl();
    	JKL.setN(7);
    	System.out.println("Check23");
    	String s="yash";
        return s;
    }
}
