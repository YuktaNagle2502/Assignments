import React, {Component} from 'react';
class Image extends Component
{
  render()
  {
    return (
        <div className='image'>
        <img className="image" src="https://ravenintel.com/wp-content/uploads/2018/01/yash3.png" width="100" height="100"></img>
          
        </div>

    );
  }
}
export default Image