import React, {Component} from 'react';
class Component2 extends Component
{
  render()
  {
    return (
        <div className='component2'>
                 
  Component2
        </div>

    );
  }
}
export default Component2