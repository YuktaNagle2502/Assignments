import React, {Component} from 'react';
class Menu extends Component
{
  render()
  {
    return (
        <div className='navbar'>
                <ul>
                <li><a href="home.html">Home</a></li>
                <li><a href="contactus.html">Aboutus</a></li>
                <li><a href="service.html">Service</a></li>
                <li><a href="contactus.html">Contactus</a></li>
                </ul>

        </div>

    );
  }
}
export default Menu