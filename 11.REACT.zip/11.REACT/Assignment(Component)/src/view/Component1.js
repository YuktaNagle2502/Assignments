import React, {Component} from 'react';
class Component1 extends Component
{
  render()
  {
    return (
        <div className='component1'>
                 
  Component1
        </div>

    );
  }
}
export default Component1