import Menu from './view/Menu';
import Component1 from './view/Component1';
import Component2 from './view/Component2';
import Logo from './view/Logo';
import Image from './view/Image';
import QueryForm from './QueryForm';
import './App.css';

function App() {
  return (
    
     <div className='wrapper'>
      <div>
   <Logo />
   
   <Menu />
   <div className='footertop'>
   <QueryForm/>
   </div>
   </div>
   <div>
    <Image/>
   <div className='content'>
   <Component1 />
   <Component2 />
   </div>
   </div>
   </div>
  );
}

export default App;
