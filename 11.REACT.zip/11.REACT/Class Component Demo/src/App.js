import logo from './logo.svg';
import './App.css';
import React,{Component} from 'react';

class App extends React.Component
{
  constructor(props)
  {
    super(props);
    this.state={
    listdata:[{"itemname":"red shirt"},{"itemname":"blue jeans"},{"itemname":"formal white shirt"},{"itemname":"jacket"}],
    testname: "react js test"
  }
  }
  render()
  {
    return (<div>
    <Items name="cloth" price="350" />
    <ul>{this.state.listdata.map((item)=><List listdata={item} />)}</ul>
    <Content tname={this.state.testname} />
    <h2>{this.props.name}</h2>
    </div>

    );
  }
}
App.defaultProps={
  name: "react training class"
}
class Items extends React.Component
{
  constructor(props)
  {
    super(props);
    this.iname=this.props.name;
    this.price=this.props.price;
  }
  render()
  {
    return (<div className='items'><h2>List of all items</h2><p>{this.iname}</p><p>{this.price}</p></div>);
  }
}
class Content extends React.Component
{
  render()
  {
    return (<div>
    <div className='content'>
      This is content section to display all content.
    <br />
    <p>{this.props.tname}</p>
    </div>
    </div>

    );
  }
}
class List extends React.Component
{
  render()
  {
    return(<ul><li>{this.props.listdata.itemname}</li></ul>)
  }
}
export default App;
