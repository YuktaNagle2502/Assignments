import React, { Component } from "react";
import { Route } from "react-router-dom";
import { Routes } from "react-router-dom";
import About from "./About";
import Contact from "./Contact";
import Navbar from "./Navbar";

class App extends Component
{
  render()
  {
    return(
      <div className="App">
        <Navbar/>
      <Routes>
        <Route exact path='/' element={<About/>}/>
        <Route path='/contact' element={<Contact/>}/>
      </Routes>
      {/* <About />
      <Contact/> */}
      </div>
    );
  }
}

export default App;
