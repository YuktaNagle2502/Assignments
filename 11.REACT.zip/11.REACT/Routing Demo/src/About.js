import React from "react";

const About = () =>
{
    return <h1><center>In the About Page</center></h1>;
}

export default About;