import React from "react";
import { Link } from "react-router-dom";
import './App.css';

function Navbar() {
    return <div >
            <Link className='nav' to="/">About</Link><br/>
            <Link className='nav' to="/contact">Contact</Link>
    </div>;
}

export default Navbar;