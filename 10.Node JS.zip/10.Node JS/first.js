var a=10;
console.log(a); //10
console.log("this is demo of console.log");

var x=9;
{
    var x=4;
    console.log(x); //4
    
}
console.log(x); //4

var y=5;
{
    let y=6;
    console.log(y); //6
}
console.log(y); //5

let z=10;
{
    let z=11;
    console.log(z); //11
    
}
console.log(z); //10

var b=12;
var b=34;
console.log(b); //34

let p=12;
//let p=24; can't redeclare let but if we want to redeclare then we have to use block 
console.log(p);