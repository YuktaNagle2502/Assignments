//this function will be called when either success or failure happened
function show(msg)
{
    console.log(msg);
}
function Palindrome(str)
{
    let a=0; 
    let b=str.length-1;
    while(a<b)
    {
        if(str[a]!=str[b]) break;
        a++;
        b--;
    }
if(a<b)
return 0;

else
return 1;
}
let mypromise= new Promise(function (myResolve,myReject) 
{
    let str="nitin";
    let a=Palindrome(str);
    if(a==1)
    myResolve("Palindrome");
    else
    myReject("Not a Palindrome");
});

mypromise.then(function(value){show(value);}, function(error){show(error);});
