var product={
    pname:"sugar",
    price:"40",
    qty:10,
    catid:3
};
var cat={
    catname:"food",
    catid:1
};

var cat_pro={...product,...cat};
console.log(cat_pro); //catid:1 is the output of both

