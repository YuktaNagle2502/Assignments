var bookdetail ={
    bname:"expert java programming",
    price:500,
    nopages:450,
    author:"herbert schildit",
    covertype:"solid waterproof"
  };
  
  function printBD({nopages,author,price,covertype,bname}) //it will map automatically no need to arrange in specific order
  {
    console.log(bname);
    console.log(price);
    console.log(author);
    console.log(nopages);
    console.log(covertype);
  }
  
  printBD(bookdetail);