function result(r) //result(32)
{
    console.log("result"+r); //result32
}
function sum(a,b,callbackfun) //sum(10,22,result) callbackfun=result
{
    var s=a+b;
    callbackfun(s); //result(32)
}
sum(10,22,result); //first it would be called