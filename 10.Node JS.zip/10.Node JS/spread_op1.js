var array1=[3,6,9];
var array2=[2,4,5];
var combarray=[...array1,...array2];
console.log(combarray);

var array3=[2,4,6,78,92,22,100];
var[f,s,t,...rem]=array3; //can't remove the first index element if we want to
console.log(f);
console.log(s);
console.log(t);
console.log(rem);