class WeekDays
{
	enum Week
	{
		SUN,MON,TUE,WED,THU,FRI,SAT;
	}
	
	public static void main(String args[])
	{
        for(Week d:Week.values())
		{
			System.out.println(d);
		}
		Week w;
		w=Week.THU;
		
	    switch(w)
	    {
		case SUN:
		System.out.println("Today is: " + Week.valueOf("SUN")+ " Index is " +Week.valueOf("SUN").ordinal());
		break;
      
		case MON:
		System.out.println("Today is: " + Week.valueOf("MON")+ " Index is " +Week.valueOf("MON").ordinal());
		break;
        
        case TUE: 
		System.out.println("Today is: " + Week.valueOf("TUE")+ " Index is " +Week.valueOf("TUE").ordinal());
		break;
        
		case WED:
		System.out.println("Today is: " + Week.valueOf("WED")+ " Index is " +Week.valueOf("WED").ordinal());
		break;
        
		case THU:
		System.out.println("Today is: " + Week.valueOf("THU")+ " Index is " +Week.valueOf("THU").ordinal());
		break;
        
		case FRI:
		System.out.println("Today is: " + Week.valueOf("FRI")+ " Index is " +Week.valueOf("FRI").ordinal());
		break;
        
		case SAT:
		System.out.println("Today is: " + Week.valueOf("SAT")+ "Index is " +Week.valueOf("SAT").ordinal());
		break;
        }
}}