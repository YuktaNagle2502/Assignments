class EnumSeason
{
	enum Seasons
	{
		SUMMER(1),WINTER(2);
		int a;
		
		Seasons(int a)
		{
			this.a=a;
		}
	}
	public static void main(String args[])
	{
		for(Seasons s: Seasons.values())
		{
			System.out.println(s+ " "+s.a);
		}
	
	Seasons s;
	s=Seasons.SUMMER;
	
	switch(s)
	    {
		case SUMMER:
		System.out.println("Season is: " + Seasons.valueOf("SUMMER")+ " Index is " +Seasons.valueOf("SUMMER").ordinal());
		break;
      
		case WINTER:
		System.out.println("Season is: " + Seasons.valueOf("WINTER")+ " Index is " +Seasons.valueOf("WINTER").ordinal());
		break;
}}}