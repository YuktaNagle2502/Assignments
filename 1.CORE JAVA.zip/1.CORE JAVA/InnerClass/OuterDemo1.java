class OuterDemo1
{
 static class Inner
 {
  void show()
  {
  System.out.println("Inner class");
  }
 }
 public static void main(String args[])
 {
  OuterDemo1.Inner obj= new OuterDemo1.Inner();
  obj.show();
 } 
}
// output = inner class
// for static inner class