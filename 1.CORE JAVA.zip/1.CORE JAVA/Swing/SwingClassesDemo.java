import javax.swing.*;
import java.awt.*;
class SwingClassesDemo extends JFrame
{
	JFrame f=new JFrame();
	JLabel label1;
	JLabel label2;
	JLabel label3;
	JTextField text1,t;
	JPasswordField text2;
	JButton button;
	JRadioButton radio1,radio2;
	SwingClassesDemo()
	{
		setSize(600,600);
		setLayout(new FlowLayout());
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		label1=new JLabel("Enter username");
		add(label1);
		text1=new JTextField(40);
		add(text1);
		
		label2=new JLabel("Enter password");
		add(label2);
		text2=new JPasswordField(40);
		add(text2);
		
		label3=new JLabel("Gender");
		add(label3);
		t=new JTextField(30);
		add(t);
		radio1=new JRadioButton("Male");
		add(radio1);
		radio2=new JRadioButton("Female");
		add(radio2);
		ButtonGroup bg=new ButtonGroup();
		bg.add(radio1);
		bg.add(radio2);
		
		button=new JButton("Login");
		add(button);
		
		
		setVisible(true);
	}
		
	public static void main(String args[])
	{
		SwingClassesDemo s=new SwingClassesDemo();
	}
}