class UncheckedException
{
	public static void main(String args[]) 
	{
		/*int a=20;
		int b=0;
		int c=a/b;*/
		String s=null;
		String str="444.4";
		int arr[]={10,11,12,13};
		/*try
		{
		System.out.println(c);
		}	
        catch(ArithmeticException e)
		{
		 e.printStackTrace();
	    }*/
		try
		{
		System.out.println(s.length());
		}
		catch(NullPointerException e1)
		{
		  e1.printStackTrace();
		}
		try
		{
		 System.out.println(arr[5]);
		}	
		catch(ArrayIndexOutOfBoundsException e2)
		{
		 e2.printStackTrace();
		}
		/*try
		{
			int x=Integer.parseInt(str);
		}
		catch(InputMismatchException e3)
		{
		 e3.printStackTrace();
		}*/
		
	}
}