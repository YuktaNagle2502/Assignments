import java.util.Scanner;
class ArrayIndexOutOfBound
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of elements in the array:");
		int a=sc.nextInt();
		
		int b[]=new int[a];
		System.out.println("Enter the elements in the array:");
		
		try
		{
			for(int i=0;i<a;i++)
				b[i]=sc.nextInt();
			System.out.println("Enter the index of the array you want to access:");
			
			int index=sc.nextInt();
			System.out.println("The array element at index "+index+"="+b[index]);
			System.out.println("The array element successfully accessed");
		}
		catch( ArrayIndexOutOfBoundsException e)
		{
			System.out.println("java.lang.arrayIndexOutOfBoundException");
}}}
			