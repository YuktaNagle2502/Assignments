import java.io.IOException;
class ThrowsDemo
{
	void display() throws IOException
	{
		throw new IOException("error");
}}
class Throws
{
	public static void main(String args[])
	{
		ThrowsDemo t=new ThrowsDemo();
		try
		{
			 t.display();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		System.out.println("Done");
}}