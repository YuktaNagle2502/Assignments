class TryCatch
{
	public static void main(String args[])
	{
		try
		{
			//String s=null;
			//System.out.println(s.length());
			System.out.println("hi");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	    System.out.println("bye");
}}