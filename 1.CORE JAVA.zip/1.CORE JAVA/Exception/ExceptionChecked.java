import java.io.FileInputStream;
class ExceptionChecked
{
	public static void main(String args[])
	{
		try
		{
		FileInputStream f=new FileInputStream("D:/xyz.txt");
		}
		//Class.forName("com.mysql.jdbc.Driver");
		catch(Exception e)
		{
			System.out.println(e);
}}}