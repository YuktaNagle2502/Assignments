import java.io.*;
class CheckedException
{
	public static void main(String args[])
	{
		try
		{
			//FileInputStream f=new FileInputStream("abcd.txt");
			Class.forName("com.mysql.jdbc.Driver");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
}
	