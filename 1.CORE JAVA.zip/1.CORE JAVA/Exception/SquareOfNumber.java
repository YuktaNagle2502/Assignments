import java.util.Scanner;
class SquareOfNumber
{
	public static void main(String args[])
	{
		String s1;
		int b;
		Scanner sc=new Scanner(System.in);
	    System.out.println("Enter an integer");
		s1=sc.next();
	    
		
		try
		{
		b=Integer.parseInt(s1);
		System.out.println(b*b);
	  }
	  catch(NumberFormatException e)
	  {
		 System.out.println("Entered input is not a valid format for an integer");
}}}