class A{}

class DemoForName
{
 public static void main(String ars[]) throws Exception
 {
   Class c= Class.forName("A");
   System.out.println(c.getName());
   
 }
}