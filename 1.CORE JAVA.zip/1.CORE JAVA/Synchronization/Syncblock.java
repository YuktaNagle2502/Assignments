class BookTicket
{
	int totalseats=12;
	void bookSeat(int seats)
	{
		synchronized(this)
		{
		if(totalseats>=seats)
		{
			System.out.println("Booked Successfully");
			totalseats=totalseats-seats;
			System.out.println("Remaining seats "+totalseats);
		}
		else
		{
			System.out.println("Seats are not available "+totalseats);
		}
	}
}}
public class Syncblock extends Thread
{
	static BookTicket b;
	int seats;
	public void run()
	{
		b.bookSeat(seats);
	}
	public static void main(String args[])
	{
		b=new BookTicket();
		Syncblock s=new Syncblock();
		s.seats=8;
		s.start();
		Syncblock s1=new Syncblock();
		s1.seats=10;
		s1.start();
	}
}
		
		