class BookTicket
{
	int totalseats=12;
	synchronized  void bookSeat(int seats)
	{
		if(totalseats>=seats)
		{
			System.out.println("Booked Successfully");
			totalseats=totalseats-seats;
			System.out.println("Remaining seats "+totalseats);
		}
		else
		{
			System.out.println("Seats are not available "+totalseats);
		}
	}
}
public class SyncMethod extends Thread
{
	static BookTicket b;
	int seats;
	public void run()
	{
		b.bookSeat(seats);
	}
	public static void main(String args[])
	{
		b=new BookTicket();
		SyncMethod s=new SyncMethod();
		s.seats=8;
		s.start();
		SyncMethod s1=new SyncMethod();
		s1.seats=10;
		s1.start();
	}
}
		
		