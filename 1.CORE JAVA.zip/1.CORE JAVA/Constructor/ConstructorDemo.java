class ConstructorDemo
{
	int i;
	String s;
	
	public ConstructorDemo()
	{
		System.out.println("default");
	}
	public static void main(String args[])
	{
		ConstructorDemo t= new ConstructorDemo();
		System.out.println(t.i);
		System.out.println(t.s);
	}
}

		