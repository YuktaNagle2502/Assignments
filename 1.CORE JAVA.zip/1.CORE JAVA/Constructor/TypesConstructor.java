class TypesConstructor
{
	/*public TypesConstructor() //User defined constructor
	{
		System.out.println("default constructor");
	}*/
	int emp_id;
	String name;
	public TypesConstructor(int i, String n) //parametrized constructor
	{
		emp_id=i;
		name=n;
	}
	void display()
	{
		System.out.println(emp_id+ "" + name);
	}
	public static void main(String args[])
	{
		//TypesConstructor t= new TypesConstructor();
		TypesConstructor t=new TypesConstructor();
		TypesConstructor t=new TypesConstructor(101,"RAJKUWAR");
		t.display();
	}
}
