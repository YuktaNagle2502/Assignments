class BoxConstructor
{
	double weight, height, depth;
	BoxConstructor(double w, double h, double d)//parametrised constructor
	{
		weight=w;
		height=h;
		depth=d;
	}
	public void volume() //method
	{
		double volume = height*weight*depth;
		System.out.println(volume);
		
	}
	public static void main(String[] args)
	{
		BoxConstructor bcs= new BoxConstructor(2,4,2);
		bcs.volume();
	}
}

		