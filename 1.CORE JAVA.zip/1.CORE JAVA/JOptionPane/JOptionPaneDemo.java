import javax.swing.*; 
class JOptionPaneDemo
{
	JFrame f;  
	JOptionPaneDemo()
	{  
	f=new JFrame();  
    String name=JOptionPane.showInputDialog(f,"Enter Name");	
	//JOptionPane.showMessageDialog(f,"Here I am");  
	}  
	public static void main(String[] args) 
	{  
	new JOptionPaneDemo();
	System.exit(0);
	}
}  