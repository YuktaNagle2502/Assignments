import java.sql.*;
import java.io.FileInputStream;

class ImageDemo
{
	public static void main(String args[])
	{
		try
		{
			//load the driver
			Class.forName("com.mysql.jdbc.Driver");
			
			//create connection
			String url="jdbc:mysql://localhost:3306/yash";
			String user="root";
			String pass="root";
			
			Connection con=DriverManager.getConnection(url,user,pass);
			if(con!=null)
			{
				System.out.println("Connection is created successfully");
			}
			else
				System.out.println("Connection is not created");
			
			//create query
			String s="insert into image(picture) values(?)";
			PreparedStatement st=con.prepareStatement(s);
			FileInputStream in=new FileInputStream("d:/yash/img.jpg");
			st.setBinaryStream(1,in,in.available()); //gives available memory
			
			st.executeUpdate();
			System.out.println("Inserted successfully");
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}