import java.sql.*;
class FirstJdbcDemo
{
	public static void main(String args[])
	{
		try
		{
			//load the driver
			Class.forName("com.mysql.jdbc.Driver");
			
			//create connection
			String url="jdbc:mysql://localhost:3306/yash";
			String user="root";
			String pass="root";
			
			Connection con=DriverManager.getConnection(url,user,pass);
			if(con!=null)
			{
				System.out.println("Connection is created successfully");
			}
			else
				System.out.println("Connection is not created");
			
			//create query
			String s="select * from employee";
			Statement st=con.createStatement();
			ResultSet set=st.executeQuery(s);
			
			//process the data
			while(set.next())
			{
				int id=set.getInt("empID");
				String name=set.getString(2);
				System.out.println("id: " +id);
				System.out.println("name: " +name);
			}
				
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}