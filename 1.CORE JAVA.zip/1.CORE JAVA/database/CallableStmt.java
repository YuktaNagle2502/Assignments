import java.sql.*;
class CallableStmt
{
	public static void main(String args[])
	{
		try
		{
			//load the driver
			Class.forName("com.mysql.jdbc.Driver");
			
			//create connection
			String url="jdbc:mysql://localhost:3306/yash";
			String user="root";
			String pass="root";
			
			Connection con=DriverManager.getConnection(url,user,pass);
			if(con!=null)
			{
				System.out.println("Connection is created successfully");
			}
			else
				System.out.println("Connection is not created");
			
			//create query
			String s="{Call insert(?,?)}" //insert is the procedure
			CallableStatement cl=con.prepareCall(); //calls the query
			cl.setInt(1,1009);
			cl.setString(2,"ABC");
			cl.execute();