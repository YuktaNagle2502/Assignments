import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.sql.*;
class UpdateDemo
{
	public static void main(String args[])
	{
		try
		{
			//load the driver
			Class.forName("com.mysql.jdbc.Driver");
			
			//create connection
			String url="jdbc:mysql://localhost:3306/yash";
			String user="root";
			String pass="root";
			
			Connection con=DriverManager.getConnection(url,user,pass);
			if(con!=null)
			{
				System.out.println("Connection is created successfully");
			}
			else
				System.out.println("Connection is not created");
			
			//create query
			/*String str="update employee set empID=2000,name='xyz' where empID=1006";
			PreparedStatement ps=con.prepareStatement(str);
			ps.executeUpdate();
			System.out.println("Updated successfully");
			con.close();*/
			
			
			String str="update employee set empID=(?),name=(?) where empID=1003";
			PreparedStatement ps=con.prepareStatement(str);
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Enter empID:");
			int empID=Integer.parseInt(br.readLine());
			System.out.println("Enter name:");
			String name=br.readLine();
			ps.setInt(1,empID);
			ps.setString(2,name);
			ps.executeUpdate();
			System.out.println("Updated successfully");
			con.close();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
			