import java.sql.*;
class PreparedStmt
{
	public static void main(String args[])
	{
		try
		{
			//load the driver
			Class.forName("com.mysql.jdbc.Driver");
			
			//create connection
			String url="jdbc:mysql://localhost:3306/yash";
			String user="root";
			String pass="root";
			
			Connection con=DriverManager.getConnection(url,user,pass);
			if(con!=null)
			{
				System.out.println("Connection is created successfully");
			}
			else
				System.out.println("Connection is not created");
			
			//create query
			String s="insert into emp values(?,?)";
			PreparedStatement ps=con.prepareStatement(s);
			ps.setInt(1,1007);
			ps.setString(2,"c");
			ps.setInt(1,1008);
			ps.setString(2,"d");
			int i=ps.executeUpdate();
				System.out.println("Data is inserted");
				
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}