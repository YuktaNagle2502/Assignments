class A
{
 A()
 {System.out.println("i am in A class Constructor");}
}
class SuperDemo3 extends A
{
 SuperDemo3()
 {
   System.out.println("i am in  SuperDemo3 Constructor");
 }
 public static void main(String args[])
 {
  SuperDemo3 sd= new SuperDemo3();
 }
}