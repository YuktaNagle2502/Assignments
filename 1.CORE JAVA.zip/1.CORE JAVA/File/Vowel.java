import java.io.File;
import java.io.*;
class Vowel
{
	public static void main(String args[]) throws Exception
	{
		int numVowels=0;
		
		BufferedReader f=new BufferedReader(new FileReader("D:/yash/combine.txt"));
		String currentLine= f.readLine();
		
		while(currentLine!=null)
		{
		for(int i=0;i<f.length();i++)
		{
			char ch=f.charAt(i);
			if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')
				numVowels++;
			
			 currentLine= f.readLine();
	}}
	System.out.println("Number of vowels are " + numVowels);
}
}		
		
		
