import java.io.FileInputStream;
import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
class BufferedOutputDemo
{
	public static void main(String args[])
	{
		try
		{
	    FileInputStream fin=new FileInputStream("d:/yash/abc.txt");
		BufferedInputStream bin=new BufferedInputStream(fin);
		
		FileOutputStream fout=new FileOutputStream("d:/yash/xyz.txt");
		BufferedOutputStream bout=new BufferedOutputStream(fout);
		int i;
		while((i=bin.read())!=-1)
		{
			System.out.println((char)i);
			bout.write(i);
		}
		
		bout.close();
		fout.close();
		bin.close();
		fin.close();
	}
	catch(Exception e)
	{
		System.out.println(e);
}}}