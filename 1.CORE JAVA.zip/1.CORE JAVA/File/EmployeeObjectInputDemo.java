import java.io.*;
class Employee implements Serializable
{
	int empId;
	String empName;
	Employee(int empId, String empName)
	{
		this.empId=empId;
		this.empName=empName;
	}
	
	public String toString()
	{
		return empId + " " + empName;
	}
}
class EmployeeObjectInputDemo
{
	public static void main(String args[]) throws Exception
	{
		File f=new File("d:/yash/abc.txt");
		
		ObjectInputStream ois=new ObjectInputStream(new FileInputStream(f));
		Employee e=(Employee)ois.readObject();
		ois.close();
		System.out.println(e);
}}
		