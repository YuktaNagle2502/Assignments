import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

class ByteArrayOutputDemo
{
	public static void main(String args[]) throws IOException
	{
    FileOutputStream f1=new FileOutputStream("d:/yash/abc.txt");
    FileOutputStream f2=new FileOutputStream("d:/yash/xyz.txt");
	ByteArrayOutputStream b=new ByteArrayOutputStream();
	b.write(80);
	b.writeTo(f1);
	b.writeTo(f2);
	b.close();
}}