import java.io.*;
import java.util.Scanner;
class Employee implements Serializable{
private String name;
private String department;
private String Designation;
private double salary;
	public void setName(String name){
	this.name = name;
}
	public String getName(){
	return name;
}
	public void setDepartment(String department){
	this.department=department;
}
	public String getDepartment(){
	return department;
}
	public void setDesignation(String Designation){
	this.Designation=Designation;
}
	public String getDesigantion(){
	return Designation;
}
	public void setSalary(double salary){
	this.salary=salary;
}
	public double getSalary(){
	return salary;
}
	public String toString(){
	return name+ " "+department+ " " + Designation+" "+salary;
}
}
class EmployeeDemo{

	public static void main(String args[]) throws Exception{
	Employee e = new Employee();
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter your name:");
	String name = sc.nextLine();
	e.setName(name);
	System.out.println("Enetr your department");
	String department = sc.nextLine();
	e.setDepartment(department);
	System.out.println("Enter your Designation");
	String Designation = sc.nextLine();
	e.setDesignation(Designation);
	System.out.println("Enter your salary");
	double salary = sc.nextInt();
	e.setSalary(salary);
	
	File f = new File("d:/yash/yash.txt");
		ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
		oos.writeObject(e);
		oos.close();
	
		
		ObjectInputStream ois =new ObjectInputStream(new FileInputStream(f));
		Employee e1 =(Employee)ois.readObject();
		ois.close();
		System.out.println(e1);
	}
}