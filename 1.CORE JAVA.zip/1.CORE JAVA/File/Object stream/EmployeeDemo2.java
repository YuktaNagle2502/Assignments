import java.io.*;
import java.util.Scanner;
class Employee implements Serializable
{
private String name;
private String department;
private String designation;
private double salary;

public Employee()
{
	System.out.println("No argument constructor");
}
public Employee(String name,String department,String designation,double salary)
{
	this.name=name;
	this.department=department;
	this.designation=designation;
	this.salary=salary;
}
public String toString()
{
	return name + " "+ department + " " + designation + " " + salary;
}
}
class EmployeeDemo2
{
	public static void main(String args[]) throws Exception
	{
		Employee e=new Employee("Yukta","Computer Science","Student",50000);
		
		File f = new File("d:/yash/data.txt");
		ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
		oos.writeObject(e);
		oos.close();
	
		
		ObjectInputStream ois =new ObjectInputStream(new FileInputStream(f));
		Employee e1 =(Employee)ois.readObject();
		ois.close();
		System.out.println(e1);
}}