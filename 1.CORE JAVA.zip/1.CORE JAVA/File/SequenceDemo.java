import java.io.FileInputStream;
import java.io.SequenceInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

class SequenceDemo
{
	public static void main(String args[]) throws IOException
	{
		FileInputStream f1=new FileInputStream("d:/yash/abc.txt");
		FileInputStream f2=new FileInputStream("d:/yash/xyz.txt");
		SequenceInputStream s=new SequenceInputStream(f1,f2);
		FileOutputStream fout=new FileOutputStream("d:/yash/combine.txt");
		int i;
		while((i=s.read())!=-1)
		{
			System.out.println((char)i);
			fout.write(i);
		}
		f1.close();
		f2.close();
		s.close();
		fout.close();
		}
}