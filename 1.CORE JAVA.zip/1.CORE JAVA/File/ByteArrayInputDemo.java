import java.io.ByteArrayInputStream;
import java.io.IOException;
class ByteArrayInputDemo
{
	public static void main(String args[]) throws IOException
	{
		byte[] a={10,20,30,65};
		
		ByteArrayInputStream b=new ByteArrayInputStream(a);
		int i=0;
		while((i=b.read())!=-1)
	    {
			System.out.println((char)i);
		}
		b.close();
	}
}