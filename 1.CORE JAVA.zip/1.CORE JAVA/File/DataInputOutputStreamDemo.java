import java.io.FileInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.DataInputStream;
import java.io.IOException;

class DataInputOutputStreamDemo
{
	public static void main(String args[]) throws IOException
	{
    FileOutputStream f1=new FileOutputStream("d:/yash/abc.txt");
    DataOutputStream dout=new DataOutputStream(f1);
    dout.writeInt(100);
	FileInputStream f2=new FileInputStream("d:/yash/abc.txt");
    DataInputStream din=new DataInputStream(f2);
	int i= din.readInt();
	System.out.println("The integer is " +i);
	dout.close();
	din.close();
	f1.close();
	f2.close();
}}