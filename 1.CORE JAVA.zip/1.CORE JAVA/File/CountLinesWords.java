import java.io.*;
class CountLinesWords
{
	public static void main(String args[]) throws Exception
	{
		int numlines=0;
		int numwords=0;
		int numchar=0;
		int numspace=0;
		
		BufferedReader f=new BufferedReader(new FileReader("D:/yash/data.txt"));
		String currentLine= f.readLine();
		
		while(currentLine!=null)
		{
			numlines++;
		String words[]=	currentLine.split(" ");
		numwords = numwords + words.length;
		
		for(String word: words)
		   numchar = numchar + word.length();
		   numspace= numspace+(words.length-1);
		   
		   currentLine= f.readLine();
		}
		System.out.println("Number of lines "+ numlines);
		System.out.println("Number of words "+ numwords);
		System.out.println("Number of characters "+ numchar);
		System.out.println("Number of spaces "+ numspace);
}}