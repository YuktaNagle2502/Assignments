 class Outer
{
	void show1()
	{
		System.out.println("hi");
	}
	
	class Inner
	{
	void show()
	{
		System.out.println("hello");
}}}
	
	class OuterDemo
	{
		public static void main(String args[])
		{
			Outer o=new Outer();  // non static
			Outer.Inner ob= o.new Inner(); //  non static
			//Outer.Inner ob=new Outer.Inner(); //static
			ob.show();
			o.show1();
}}