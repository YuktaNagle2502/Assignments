import java.util.Scanner;
class IsEmpty
{
 public static void main(String args[])
{
 Scanner sc=new Scanner(System.in);
 System.out.println("Enter the string:");
 String name=sc.nextLine();
 boolean b=name.isEmpty();
 if(b==true)
 { System.out.println("Name is empty");}
 else
{ System.out.println("Name is not empty");}}}