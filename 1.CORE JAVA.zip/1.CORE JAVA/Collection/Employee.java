import java.util.Iterator;
import java.util.Enumeration;
import java.util.Vector;
class EmployeeDemo
{
	String emp_name;
	int emp_id;
	
	EmployeeDemo(String emp_name,int emp_id)
	{
		this.emp_name=emp_name;
		this.emp_id=emp_id;
	}
	public String toString()
	{
	return "Employee [name = " + emp_name + ", id = " + emp_id + "]";
	}
}	
	public class Employee
	{
	public static void main(String args[])
	{
		Vector<EmployeeDemo> v=new Vector<EmployeeDemo>();
		v.add(new EmployeeDemo("Yukta",7890));
		v.add(new EmployeeDemo("Yash",5679));
		
		Enumeration<EmployeeDemo> e=v.elements();  // using enumeration
		while(e.hasMoreElements())
		{
		System.out.println(e.nextElement());
		}
		
		Iterator<EmployeeDemo> i=v.iterator();     // using iterator
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}
	}
