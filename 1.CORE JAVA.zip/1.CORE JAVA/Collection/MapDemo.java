import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;
import java.util.*;
import java.util.*;

class MapDemo
{
	public static void main(String args[])
	{
		Map<Integer,String> map=new HashMap<Integer,String>();
		map.put(10,"yash");
		map.put(11,"yukta");
		for(Map.Entry m: map.keySet())
		{
			System.out.println("key: "+m.getKey());
		}
		Collections.sort();
	}
}