import java.util.*;
class Country
{
	Map<String,String> m1=new HashMap<String,String>();
	
	public Map<String,String> saveCountryCapital(String CountryName,String Capital)
	{
		m1.put("India","Delhi");
		m1.put("Japan","Tokyo");
		return m1;
	}
	
	public String getCapital(String CountryName)
	{
	    return m1.get(Capital);
	}
	
	public String getCountry(String CapitalName)
	{
		 return m1.get(CountryName);
	}
	
		Set s=m1.entrySet();
		Iterator i=s.iterator();
		
		while(i.hasNext())
		{
			Map.Entry m1=(Map.Entry)i.next();
			System.out.println("key: "+m1.getKey()+ " value: "+m1.getValue());
		}
		
		Map<String,String> m2=new HashMap<String,String>();
		m2.put("Delhi","India");
		m2.put("Tokyo","Japan");
		return m2;
	}
}

public class Question4_Country
{
    public static void main(String args[])
	{
		Set s=m1.entrySet();
		Iterator i=s.iterator;
		
		while(i.hasNext())
		{
			Map.Entry m1=(Map.Entry)i.next();
			System.out.println("key: "+m1.getKey()+ " value: "+m1.getValue());
		}
		
		ArrayList<String> a=new ArrayList<String>();
		a.add("India");
		a.add("Japan");
		
		
		return a;
	}
}
		
		
		
		

    	