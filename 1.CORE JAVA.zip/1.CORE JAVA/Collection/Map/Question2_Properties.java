import java.util.*;
class Question2_Properties
{
	public static void main(String args[])
	{
		Properties p=new Properties();
		p.setProperty("Maharashtra","Mumbai");
		p.setProperty("Karnataka","Bengaluru");
		
		Set s=p.entrySet();
		Iterator i=s.iterator();
		
		while(i.hasNext())
		{
			Map.Entry entry=(Map.Entry)i.next();
			System.out.println("key: "+entry.getKey()+ " value: "+entry.getValue());
		}
	}
}