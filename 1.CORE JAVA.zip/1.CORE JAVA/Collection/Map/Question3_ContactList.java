import java.util.*;
class Question3_ContactList
{
	public static void main(String args[])
	{
		Map<String,Integer> map=new HashMap<String,Integer>();
		map.put("Yukta",8989799);
		map.put("Yash",6524628);
		
		Set s=map.entrySet();
		Iterator i=s.iterator();
		
		while(i.hasNext())
		{
			Map.Entry entry=(Map.Entry)i.next();
			
			if(entry.getKey().equals("Yash"))
			{
				System.out.println("key exists");
			}
			
		}
		
		 s=map.entrySet();
		 i=s.iterator();
		
		
		while(i.hasNext())
		{
			Map.Entry entry=(Map.Entry)i.next();
			
			if(entry.getValue().equals(6524628))
			{
				System.out.println("value exists");
			}
			
		}
		
		s=map.entrySet();
		i=s.iterator();
		
		
		while(i.hasNext())
		{
			Map.Entry entry=(Map.Entry)i.next();
			System.out.println("Name: "+entry.getKey()+ " Phone number: "+entry.getValue());
	    }	
			
	}
}