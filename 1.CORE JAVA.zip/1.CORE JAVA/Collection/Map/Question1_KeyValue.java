import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.*;

class Question1_KeyValue
{
	public static void main(String args[])
	{
		Map<String,String> hs=new HashMap<String,String>();
        hs.put("yukta","Indore");
        hs.put("yash","Bhopal");
		
        Set s=hs.entrySet();
		Iterator i=s.iterator();
		
		while(i.hasNext())
		{
			Map.Entry entry=(Map.Entry)i.next();
			
			if(entry.getKey().equals("yash"))
			{
				System.out.println("key exists");
			}
			
		}
		
		 s=hs.entrySet();
		 i=s.iterator();
		
		
		while(i.hasNext())
		{
			Map.Entry entry=(Map.Entry)i.next();
			
			if(entry.getValue().equals("Indore"))
			{
				System.out.println("value exists");
			}
			
		}
		
		s=hs.entrySet();
		i=s.iterator();
		
		
		while(i.hasNext())
		{
			Map.Entry entry=(Map.Entry)i.next();
			System.out.println("key: "+entry.getKey()+ " value: "+entry.getValue());
		}
			
		
		
	}
}