import java.util.HashSet;
import java.util.Iterator;

class Country 
{
	HashSet<String> h1 = new HashSet<String>();
	
	public HashSet<String> saveCountryName(String CountryName) 
	{
		h1.add(CountryName);
		return h1;
	}
	
	public String getCountry(String CountryName)
	{
		Iterator<String> i = h1.iterator();
		
		while (i.hasNext()) 
		{
			if (i.next().equals(CountryName))
				
				return CountryName;
		}
		return null;
	}
}

public class CountryDemo {

	public static void main(String[] args)
	{	
		Country c = new Country();
		c.saveCountryName("America");
		c.saveCountryName("India");

		System.out.println(c.getCountry("England"));
		System.out.println(c.getCountry("India"));		
	}

}