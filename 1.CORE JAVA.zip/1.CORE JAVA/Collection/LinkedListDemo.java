import java.util.LinkedList;
//import java.util.Iterator;
import java.util.ListIterator;
class LinkedListDemo
{
	public static void main(String args[])
	{
		LinkedList<String> a=new LinkedList<String>();
		a.add("Summer");
		a.addFirst("Winter");
		
		ListIterator<String> li= a.listIterator();
		li.next(); 
		System.out.println(li.next());
	}
}