import java.util.HashSet;
import java.util.Iterator;

class HashEmployee
{
	public static void main(String args[])
	{
		HashSet<String> hs=new HashSet<String>();
		hs.add("Yukta");
		hs.add("Yash");
		hs.add("Kartik");
		
		Iterator i=hs.iterator();
		while(i.hasNext())
		{
			System.out.println("Employee name: " + i.next());
		}
	}
}