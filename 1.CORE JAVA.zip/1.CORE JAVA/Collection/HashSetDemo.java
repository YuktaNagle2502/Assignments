import java.util.HashSet;
import java.util.Iterator;
public class HashSetDemo
{
	public static void main(String args[])
	{
		HashSet<String> a=new HashSet<String>();
		a.add("Summer");
		a.add("Winter");
		
		Iterator i=a.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}
}