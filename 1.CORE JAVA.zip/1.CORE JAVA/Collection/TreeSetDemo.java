import java.util.TreeSet;
import java.util.Iterator;
public class TreeSetDemo
{
	public static void main(String args[])
	{
		TreeSet<String> ts=new TreeSet<String>();
		ts.add("one");
		ts.add("two");
		ts.add("three");
		ts.add("four");
		
		Iterator i=ts.iterator();
		i.next();
		i.next();
		i.next();
		
		while(i.hasPrevious())
		{
			System.out.println(i.previous());
		}
	}
}
		