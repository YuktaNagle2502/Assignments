public class NameOfThread
{
	public static void main(String args[])
	{
		System.out.println(Thread.currentThread().getName()); //main
		Thread.currentThread().setName("Yukta");
		System.out.println(Thread.currentThread().getName());
	}
}