class m1 extends Thread
{
	public void run()
	{
	  System.out.println("I am in m1");
	}
}	
class m2 extends Thread
{
	public void run()
	{
	  System.out.println("I am in m2");
	}
}			
class m3 extends Thread
{
	public void run()
	{
	  System.out.println("I am in m3");
	}
}	

class MultipleTaskMultipleThread
{
  public static void main(String args[])
  {
    m1 t1=new m1();
    t1.start();
    m2 t2=new m2();
    t2.start();
	m3 t3=new m3();
    t3.start();
  }
}