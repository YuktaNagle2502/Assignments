 class SingleTaskSingleThread extends Thread
{
	public void run()
	{
		System.out.println("Thread Started");
	}
	public static void main(String args[])
	{
		ThreadDemo td=new ThreadDemo();
		td.start();
	}
}