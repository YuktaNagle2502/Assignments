public class Daemon extends Thread
{
	public void run()
	{
		if(Thread.currentThread().isDaemon())
		{
			System.out.println("In Daemon Method");
		}
		else
		{
			System.out.println("Not in Daemon Method");
		}
	}
	
	 public static void main(String args[])
	 {
		 System.out.println("Main Thread"); // if commented then nothing will be shown in output
		 //Thread.currentThread().setDaemon(true);
		 Daemon td=new Daemon();
		 td.setDaemon(true);
		 td.start();
		 //td.setDaemon(true);
	 }
}