public class ThreadNameDemo extends Thread
{
	public void run()
	{
		System.out.println("run: "+Thread.currentThread().getName());
	}
    public static void main(String args[])
	{
		System.out.println(Thread.currentThread().getName()); //main
		ThreadNameDemo t1=new ThreadNameDemo();
		t1.setName("t1 thread"); //Thread-0
		t1.start(); 
		
		ThreadNameDemo t2=new ThreadNameDemo();
		t2.setName("t2 thread"); //Thread-1
		t2.start();  
	}
}