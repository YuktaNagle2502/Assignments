public class Priority extends Thread
{
	public void run()
	{
		System.out.println("in run");
		System.out.println(Thread.currentThread().getPriority()); //9
	}
    public static void main(String args[])
	{
		System.out.println(Thread.currentThread().getPriority()); //5
		Thread.currentThread().setPriority(MAX_PRIORITY); //10
		System.out.println(Thread.currentThread().getPriority());
		Thread.currentThread().setPriority(1); //1
		System.out.println(Thread.currentThread().getPriority());
		
		Priority p=new Priority();
		p.setPriority(9);
		p.start();
	}
}
		