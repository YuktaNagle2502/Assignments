public class RunnableInterfaceDemo implements Runnable
{
	public void run()
	{
		System.out.println("Thread Started");
	}
	public static void main(String args[])
	{
		Thread td1=new Thread(new RunnableInterfaceDemo());
		td1.start();
	}
}