public class SingleTaskMultipleThread extends Thread
{
	public void run()
	{
		System.out.println("Thread Started");
	}
	public static void main(String args[])
	{
		ThreadDemo td=new ThreadDemo();
		td.start();
		ThreadDemo td1=new ThreadDemo();
		td1.start();
	}
}