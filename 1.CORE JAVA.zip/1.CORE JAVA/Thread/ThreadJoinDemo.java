public class ThreadJoinDemo extends Thread
{
	//static Thread mt;
	public void run()
	{
		try
		{
			//mt.join();
			for(int i=1;i<=3;i++)
			{
				System.out.println("run thread"+i);
				Thread.sleep(1000);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void main(String args[]) throws Exception
	{
		//mt=Thread.currentThread(); // main thread
		ThreadJoinDemo tj=new ThreadJoinDemo();
		tj.start();
		tj.join();
		try
		{
			for(int i=1;i<=3;i++)
			{
				System.out.println("main thread"+i);
				Thread.sleep(1000);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}