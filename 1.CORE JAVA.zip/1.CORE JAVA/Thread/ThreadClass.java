class ThreadClass extends Thread
{
	public void run()
	{
		System.out.println("Thread Started");
	}
	public static void main(String args[])
	{
		ThreadClass td=new ThreadClass();
		td.start();
	}
}