public class ThreadInterrupt extends Thread
{
	public void run()
	{
		System.out.println(Thread.interrupted());
		System.out.println(Thread.interrupted()); 
		//System.out.println(Thread.currentThread().isInterrupted());
		//System.out.println(Thread.currentThread().isInterrupted());
		for(int i=1;i<=3;i++)
		{
		try
		{
		    System.out.println(i);
		    Thread.sleep(2000);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		}
	}

	public static void main(String args[])
	{
		ThreadInterrupt ts=new ThreadInterrupt();
		ts.start();
		ts.interrupt();
	}
}
