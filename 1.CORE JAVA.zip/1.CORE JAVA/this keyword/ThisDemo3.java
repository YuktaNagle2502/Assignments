class ThisDemo3
{
	ThisDemo3()
	{
		//this(10);
		System.out.println("No Argument Constructor");
	}
	This Demo3
	{
		this();
		System.out.println("This is parametrized Constructor");
	}
	
	public static void main(String args[])
	{
	  ThisDemo3 obj= new ThisDemo3(10);
	  
	}
}
