class T1
{
	T1(ThisDemo5 obj)
	{
		System.out.println("Y1 Method");
		
	}
 class ThisDemo5
	{
	 void y1()
	 {
		 
		t1 obj= new T1(this);//T1 class constructor as an argument(this)
	 }
	
	public static void main(String args[])
	{
	  ThisDemo5 obj1= new ThisDemo5();
	  obj1.y1();
	  
	}
}
