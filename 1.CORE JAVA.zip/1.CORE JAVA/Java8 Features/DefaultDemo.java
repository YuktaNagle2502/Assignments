interface House
{
	void hall();
	default void gallery() //we can define methods in interface using default keyword
	{
		System.out.println("I am in gallery");
	}
}
class Home implements House
{
	public void hall()
	{
		System.out.println("I am in hall");
	}
}
public class DefaultDemo 
{
	public static void main(String args[])
	{
	  House h=new Home();
	  h.hall();
	  h.gallery();
	}
}
