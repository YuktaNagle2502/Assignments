import java.util.List;
import java.util.ArrayList;
public class StreamDemo
{
	public static void main(String args[])
	{
		List<Integer> values=new ArrayList<>();
		for(int i=1;i<=10;i++)
		{
			values.add(i);
		}
		values.stream().forEach(System.out::println);
	}
}
