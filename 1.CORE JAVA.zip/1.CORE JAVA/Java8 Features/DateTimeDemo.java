import java.time.LocalDate;
import java.time.Month;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.Year;
public class DateTimeDemo
{
   public static void main(String args[])
	{
		LocalDate l=LocalDate.now();
		System.out.println("current date is: "+l);
		
		LocalDate ld=LocalDate.of(2000,Month.FEBRUARY,29); 
		System.out.println("specified date is: "+ld);
		
		LocalTime t=LocalTime.now(); 
		System.out.println("current time is: "+t);
		
		LocalTime td=LocalTime.of(18,11,05,990); 
		System.out.println("specified time is: "+td);
		
		LocalDateTime dt=LocalDateTime.now(); 
		System.out.println("current date and time is: "+dt);
		/*
		for(String a: ZoneId.getAvailableZoneIds())
		{
			System.out.println(a);
		}
		*/	
		LocalTime s=LocalTime.now(ZoneId.of("Europe/Amsterdam"));
		System.out.println("specified zone time : "+s);
		
		ZonedDateTime currentZone=ZonedDateTime.now();
		System.out.println("current zone is: "+currentZone);
		
		Year y= Year.of(2004);
		boolean b=y.isLeap();
		if(b==true)
			System.out.println("It is a leap year");
		else
			System.out.println("It is not a leap year");
	}
}