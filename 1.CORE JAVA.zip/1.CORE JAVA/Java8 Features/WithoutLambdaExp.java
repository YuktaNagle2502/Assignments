interface A
{
	public void display(int i);
}
public class WithoutLambdaExp
{
	public static void main(String args[])
	{
	 A obj=new A()	  //providing implementation of interface A //Anonymous Inner Class
	  {
		public void display(int i)
		{
			System.out.println("Yash Tech" +i);
		}
	  };
	  obj.display(10);
	}
}