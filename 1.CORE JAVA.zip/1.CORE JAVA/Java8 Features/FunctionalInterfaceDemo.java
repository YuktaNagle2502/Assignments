interface Books
{
	void read();
}
class FunctionalInterfaceDemo
{
	public static void main(String args[])
	{
		Books b=()->
		{
			System.out.println("Reading");
		    System.out.println("Learning");
		};
		b.read();
	}
}
			