interface A
{
	public void display(int i);
}
public class LambdaExpression
{
	public static void main(String args[])
	{
	  A obj; // we don't need method name,parameter and return type all things are present in interface 
	  obj=i-> System.out.println("Yash Tech" +i); //replacement of inner class
	  
	  obj.display(11);
	}
}

	