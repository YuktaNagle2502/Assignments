import java.util.regex.Pattern;
class PatternClass
{
	public static void main(String args[])
	{
		System.out.println(Pattern.matches("yu*ta","yukta"));
	}
}