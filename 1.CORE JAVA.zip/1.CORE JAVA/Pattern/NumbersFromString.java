import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class NumbersFromString
{
	public static void main(String args[])
	{
		Pattern pattern=Pattern.compile("\\d+");  // regular expression to match digit in a string
		Matcher m=pattern.matcher("89086yukta56789yash09");
		
		while(m.find())
		{
			System.out.println(m.group());
		}
	}
}
		