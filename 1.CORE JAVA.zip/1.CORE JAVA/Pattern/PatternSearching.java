import java.util.regex.Pattern;
import java.util.regex.Matcher;
class PatternSearching
{
	public static void main(String args[])
	{
		Pattern pattern=Pattern.compile("yukta"); //creating a pattern to be searched //pattern object
		Matcher m=pattern.matcher("findnameyukta"); // search above pattern in it //matcher object
		while(m.find())
			System.out.println("Pattern found from " +m.start()+" to "+(m.end()-1));
	}
}