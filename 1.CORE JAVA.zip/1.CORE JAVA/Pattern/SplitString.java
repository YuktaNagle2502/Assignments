public class SplitString
{
	public static void main(String args[])
	{
		String lines="Welcome\r\nto\r\nyash\r\ntechnologies";
		String s[]=lines.split("\\n");
		for(String a:s)
		{
			System.out.println(a);
		}
	}
}