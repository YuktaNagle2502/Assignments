import java.util.regex.Pattern;
import java.util.regex.Matcher;
public class SubString
	{
		public static void main(String args[])
		{
			String s="bhsjjiii'yukta'usjkaklz'nagle'";
			Pattern pattern=Pattern.compile("'(.*?)'");
			Matcher m=pattern.matcher(s);
		
		while(m.find())
		{
			System.out.println(m.group());
		}
		}
	}