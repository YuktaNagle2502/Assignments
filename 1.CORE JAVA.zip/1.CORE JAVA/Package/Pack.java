import testpackage.Foundation;
class Pack
{
	public static void main(String args[])
	{
		Foundation f=new Foundation();
		//f.var1=4;
		//f.var2=5;
		//f.var3=6;
		f.var4=7;
		//System.out.println(f.var1);
		//System.out.println(f.var2);
		//System.out.println(f.var3);
		System.out.println(f.var4);
}}