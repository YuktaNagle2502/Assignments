package com.automobile.twowheeler;
import com.automobile.Vehicle;
public class Hero extends Vehicle
{
	public int getSpeed()
	{
		return 60;
	}
	public void getRadio()
	{
		System.out.println("Radio");
	}
	public String getModelName()
	{
		return "Hero";
	}
	public String getRegistrationNumber()
	{
		return "0010";
	}
	public String getOwnerName()
	{
		return "Yash";
	}
}