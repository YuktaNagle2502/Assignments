package testpackage;
public class Foundation
{
	//private int var1;
	//default int var2;
	//protected int var3;
	public int var4;
}