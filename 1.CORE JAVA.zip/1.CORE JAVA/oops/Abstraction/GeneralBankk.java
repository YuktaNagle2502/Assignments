abstract class GeneralBank
{
	abstract double getSavingsInterestRate();
	abstract double getFixedDepositInterestRate();
}
class ICICIBank extends GeneralBank 
{
    double getSavingsInterestRate()
	{
		return 4;
	}
	double getFixedDepositInterestRate()
	{
		return 8.5;
	}
}
class SBIBank  extends  GeneralBank
{
    double getSavingsInterestRate()
	{
		return 4;
	}
   double getFixedDepositInterestRate()
	{
		return 7;
	}
}
class GeneralBankk
{
public static void main(String args[])
{
	ICICIBank i=new ICICIBank();
	System.out.println("Savings: "+i.getSavingsInterestRate()+"%"+"  fixed: "+i.getFixedDepositInterestRate()+"%");
	
	SBIBank s=new SBIBank();
	System.out.println("Savings:"+s.getSavingsInterestRate()+"%"+"  fixed: "+s.getFixedDepositInterestRate()+"%");
	
	GeneralBank g=new SBIBank();
	System.out.println("Savings:"+g.getSavingsInterestRate()+"%"+"  fixed: "+g.getFixedDepositInterestRate()+"%");
}}