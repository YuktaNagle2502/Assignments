abstract class Compartment
{
	public abstract String notice();
}
class FirstClass extends Compartment
{
	public String notice()
	{
		System.out.println("First Compartment");
		return "First Compartment";
	}
}
class Ladies extends Compartment
{
	public String notice()
	{
	    System.out.println("Second Compartment");
		return "Second Compartment";
	}
}
class General extends Compartment
{
	public String notice()
	{
	 System.out.println("Third Compartment");
	 return "Third Compartment";
	} 
}
class Luggage extends Compartment
{
	public String notice()
    {
	  System.out.println("Fourth Compartment");
	  return "Fourth Compartment";
	}	
}
class TestCompartment
{
	public static void main(String args[])
	{
		Compartment c[]=new Compartment[10];
		double i=Math.random()*5;
		int x=(int)i;
		System.out.println(x);
		
		switch(x)
		{
			case 1: c[0]=new FirstClass();
			c[0].notice();
			break;
			
			case 2: c[1]=new Ladies();
			c[0].notice();
			break;
			
			case 3: c[0]=new General();
			c[2].notice();
			break;
			
			case 4: c[4]=new Luggage();
			c[3].notice();
			break;
			
			default: System.out.println("Not valid"); 
			
}}}