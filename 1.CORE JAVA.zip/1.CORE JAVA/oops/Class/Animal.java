class Animal
{
 void run()
 {
	 
	System.out.println("This is run method output");
 } 
		
 public static void main(String args[])
 {
    System.out.println("Hello"); 
  Animal sheru= new Animal();
   sheru.run();
 
 
 }




}