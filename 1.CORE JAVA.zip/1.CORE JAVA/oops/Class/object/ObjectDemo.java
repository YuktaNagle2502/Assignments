class ObjectDemo
{
	void eat()
	{
		System.out.println("Sheru is eating");
	}
	public void run()
	{
		System.out.println("Sheru is running");
	}
	public static void main(String args[])
	{
		System.out.println("hello this is object demo");
		ObjectDemo sheru=new ObjectDemo();
		sheru.eat();
		sheru.run();
		Birds b1=new Birds();
		b1.fly();
	}
}
class Birds
{
	void fly()
	{
		System.out.println("birds flying");
	}
}
