class Fruit
{
	String name;
	String taste;
	String size;
	void eat()
	{
		name="Graps";
		taste="Sweet";
	}
}
	
class Apple extends Fruit
{
	public void eat()
	{
		taste="More Sweet than Graps";
		System.out.println(taste);
	}
}
class Orange extends Fruit
{
	public void eat()
	{
		taste="Sweet-tart";
		System.out.println(taste);
	}
}
class FruitOverride 
{
	public static void main(String args[])
	{
		Apple obj= new Apple();
		Orange obj1=new Orange();
		obj.eat();
		obj1.eat();
	}
}		
