class Human
{
	public void eat()
	{
		System.out.println("Human in eating");
	}
}
class OverrideBoy extends Human
{
	public void eat()
	{
		System.out.println("Boy is eating");
	}
	public static void main(String args[])
	{
		OverrideBoy obj= new OverrideBoy();
		obj.eat();
	}
}		
