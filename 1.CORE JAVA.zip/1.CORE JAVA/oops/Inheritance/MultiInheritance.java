class Demo1
{
	void show1()
	{
		System.out.println("hi");
}}

class Demo2 extends Demo1
{
	void show2()
	{
		System.out.println("hello");
}}




class MultiInheritance extends Demo2
{
	public static void main(String args[])
	{
		MultiInheritance s= new MultiInheritance();
		s.show1();
		s.show2();
}}