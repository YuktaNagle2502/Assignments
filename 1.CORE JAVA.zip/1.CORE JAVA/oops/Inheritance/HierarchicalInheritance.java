class Demo1
{
	void show1()
	{
		System.out.println("hi");
}}

class Demo2 extends Demo1
{
	void show2()
	{
		System.out.println("hello");
}}

class HierarchicalInheritance extends  Demo1
{
	void show3()
	{
		System.out.println("bye");
}

	public static void main(String args[])
	{
		HierarchicalInheritance s= new HierarchicalInheritance();
		s.show1();
		s.show3();
}}