class Demo
{
	void show()
	{
		System.out.println("hi");
}}

class SingleInheritance extends Demo
{
	public static void main(String args[])
	{
		SingleInheritance s= new SingleInheritance();
		s.show();
}}