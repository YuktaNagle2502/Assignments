class Students
{
	private int stu_id;
	public void setStuId(int stu_id)
	{
		this.stu_id= stu_id;
	}
	public int getStuId()
	{
		return stu_id;
	}
}
class EncapsulatoinDemo
{
	public static void main(String [] args)
	{
		Students s=new Students();
		s.setStuId(101);
		System.out.println(s.getStuId());
	}
}