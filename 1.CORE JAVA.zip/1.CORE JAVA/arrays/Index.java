class Index
{
 public static void main(String args[])
 { 
  int[] a=new int[]{15,20,78,67};
  int x=20, index=-1;
  
  for(int i=0;i<a.length;i++)
  
  {
   if(a[i]==x)
   {
   index=i;
   break;
   }}
   if(index==-1)
   {
   System.out.println("Given number is not present in the array");}
   else
    {
   System.out.println("Given number is present in the array");}}}
  