class LargestSmallest
{ 
 public static void main(String args[])
{
 int []a=new int[]{34,67,55,88,23};
 int largestno=a[0], secondlargestno=0;
 int smallestno =a[0], secondsmallestno=0;
 
 for(int i=0;i<a.length;i++)
 {
  if(a[i]>largestno)
  {
   secondlargestno=largestno;
   largestno=a[i];
  }
   else if(a[i]<smallestno)
  {
   secondsmallestno=smallestno;
   smallestno=a[i];
 }}
 System.out.println("The two largest numbers are" +largestno+" "+secondlargestno);
System.out.println("The two smallest numbers are" +smallestno+" "+secondsmallestno);}}
		