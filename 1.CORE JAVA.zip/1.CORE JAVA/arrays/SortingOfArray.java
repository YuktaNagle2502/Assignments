class SortingOfArray
{
 public static void main(String args[])
 {
  int[] a= new int[]{13,67,88,43,11};
  int x = 0;    
  for (int i = 0; i <a.length; i++) {     
  for (int j = i+1; j <a.length; j++) {     
     if(a[i] >a[j]) {    
     x = a[i];    
     a[i] = a[j];    
     a[j] = x;}}} 
	 
  for (int i = 0; i <a.length; i++) {     
     System.out.print(a[i] + " ");}}}   