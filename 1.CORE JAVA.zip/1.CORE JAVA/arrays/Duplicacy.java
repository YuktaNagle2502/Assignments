class Duplicacy
{
 public static void main(String args[])
 {
  int[] a= new int[]{18,67,98,21,31,21};
  int remove=0;
  for(int i=0;i<a.length;i++)
  {
   for(int j=i+1;j<a.length;j++)
   {
   if(a[i]==a[j])
   remove=j;}}

   for(int i=0;i<a.length;i++)
   if(i!=remove)
    System.out.println(a[i]);}}