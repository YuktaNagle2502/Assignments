class MinMax
{ 
 public static void main(String args[])
 {
  int[] a=new int[]{10,20,30,40};
  int max=a[0];
  int min=a[0];
  for(int i=1;i<a.length;i++)
  {
  if(max<a[i])
  {max=a[i];}
  
 
  if(min>a[i])
  {min=a[i];}}
 System.out.println("Min element is" + min);
 System.out.println("Max element is" + max);}}