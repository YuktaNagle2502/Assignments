class OneDimensional
{
 public static void main(String args[])
{
 int[] a= new int[]{10,20,30};
 int sum=0;
 for(int i=0;i<a.length;i++)
 {
  sum=sum+a[i];
  }
  System.out.println("sum of array elements are:" +sum);
  double avg=(sum/a.length);
  System.out.println("avg of array elements are:" +avg);}}