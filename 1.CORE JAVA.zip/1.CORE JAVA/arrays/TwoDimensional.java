class TwoDimensional
{
 public static void main(String args[])
 {
  int sum=0;
  int[][] a= new int[][]{{30,80},{45,55}};
  for(int i=0; i<a.length; i++)
  {
   for(int j=0; j<a[i].length; j++)
   {
   sum=sum+a[i][j];
  }
  }
   System.out.println("Sum is:"+sum);
   System.out.println("Avg is:"+sum/4);
}}
   