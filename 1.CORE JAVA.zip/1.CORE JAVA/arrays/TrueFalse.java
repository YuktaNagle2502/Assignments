class TrueFalse
{ 
 public static void main(String args[])
 {
  int[] a=new int[]{1,4,1,4};
  int i,j=0;
  for(i=0;i<a.length;i++)
  {
   System.out.println(a[i]+" ");
   }
  for(i=0;i<a.length;i++)
  {
  if(a[i]==1 || a[i]==4)
  j++;}
  
  if(j==a.length)
  System.out.println("True");
  else
  System.out.println("False");}}