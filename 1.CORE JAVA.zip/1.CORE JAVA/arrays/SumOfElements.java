class SumOfElements
{
	public static void main(String args[])
	{
		int k[]={10,3,6,1,2,7,9};
		int sum=0;
		for(int i=0;i<k.length;i++)
		{
			if(k[i]==6)
			{
				for(int j=i+1; j<k.length;j++)
				{
					i=j;
					continue;
				}
			}
			sum=sum+k[i];
		}
		System.out.println(sum);
}}
		