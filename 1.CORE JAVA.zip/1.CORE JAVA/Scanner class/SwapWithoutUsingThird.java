import java.util.Scanner;
class SwapWithoutUsingThird
{
	public static void main(String args[])
	{
		System.out.println("Enter the values of a and b");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println("Swapped values of a and b are: " + a +" "+ b );
}}