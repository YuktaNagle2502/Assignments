import java.util.Scanner;
class Swap
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the values of a and b: ");
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c;
		c=a;
		a=b;
		b=c;
		System.out.println("Swapped values are: " + a + " "+ b);
}}
		
		
	