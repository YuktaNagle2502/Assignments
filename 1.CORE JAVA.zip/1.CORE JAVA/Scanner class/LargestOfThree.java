import java.util.Scanner;

class LargestOfThree
{
 public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter 1st,2nd and 3rd value");
	int i1=sc.nextInt();
	int i2=sc.nextInt();
	int i3=sc.nextInt();
	if(i1>=i2 && i1>=i3)
	System.out.println("Largest is "+i1);
	else if(i2>=i1 && i2>=i3)
    System.out.println("Largest is "+i2);
	else 
    System.out.println("Largest is "+i3);
}}