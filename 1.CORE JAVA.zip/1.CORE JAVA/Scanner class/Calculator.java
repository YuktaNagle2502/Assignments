import java.util.Scanner;
class Calculator
{
 public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	double result;
	System.out.println("Select one operator: +,-,*,/ " );
	char op=sc.next().charAt(0);
	
	System.out.println("Enter the value of a and b");
	int a=sc.nextInt();
	int b=sc.nextInt();
	
	switch(op)
	{
	case '+': 
	result=a+b;
	System.out.println("Addition is " +result);
	break;
	
	case '-':
    result=a-b;	
	System.out.println("Subtraction is " +result);
	break;
	
	case '*':
	result=a*b;
	System.out.println("Multiplication is " +result);
	break;
	
	case '/':
	result=a/b;
    System.out.println("Division is " +result);
	break;
	
	default:
	System.out.println("Not valid");
	break;}
    sc.close();
}}