package com.yash.aopimpl.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class MyAspect {
	
	@Pointcut("execution(* com.yash.aopimpl.services.PaymentServiceImpl.makePayment()")
	public void PointcutExpression()
	{
		System.out.println("In the pointcut");
	}
	
	@Before("PointCutExpression()")
	
	{
		
	}
	
	
	/*
	@Before("execution(* com.yash.aopimpl.services.PaymentServiceImpl.makePayment())")
	public void printBefore() {
		System.out.println("Payment Initilaized");
	}

	@After("execution(* com.yash.aopimpl.services.PaymentServiceImpl.makePayment())")
	public void printAfter() {
		System.out.println("Payment Completed");
	}
	*/
}
