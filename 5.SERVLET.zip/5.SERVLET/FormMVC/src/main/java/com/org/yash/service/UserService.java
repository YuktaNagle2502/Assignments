package com.org.yash.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.org.yash.User;
import com.org.yash.DAO.UserDAO;

@Service
public class UserService {
	@Autowired
	private UserDAO userDao;
	
	
public UserDAO getUserDao() {
		return userDao;
	}


	public void setUserDao(UserDAO userDao) {
		this.userDao = userDao;
	}


public int createUser(User user)
{
	return this.userDao.saveUser(user);
}
public List<User> getUsers()
{
	return this.userDao.getUser();
}
public void deleteData(int id)
{
	this.userDao.delete(id);
}
public void updateUser(User user)
{
	this.userDao.update(user);
}
}
