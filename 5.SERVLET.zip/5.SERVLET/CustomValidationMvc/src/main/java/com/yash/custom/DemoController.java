package com.yash.custom;  
  
import javax.validation.Valid;  
import org.springframework.stereotype.Controller;  
import org.springframework.ui.Model;  
import org.springframework.validation.BindingResult;  
import org.springframework.web.bind.annotation.ModelAttribute;  
import org.springframework.web.bind.annotation.RequestMapping;  
  
@Controller  
public class DemoController {  
      
    @RequestMapping("/login")  
    public String showForm(Model theModel) {  
          
        theModel.addAttribute("log", new Login());  
          
        return "viewpage";  
    }  
      
    @RequestMapping("/loginagain")  
    public String processForm(  
            @Valid @ModelAttribute("log") Login log,  
            BindingResult br) {  
                  
        if (br.hasErrors()) {  
            return "viewpage";  
        }  
        else {  
            return "final";  
        }  
    }  
}  